/** Automatically generated file. DO NOT MODIFY */
package com.javapapers.android.sqlitestorageoption;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}