/** Automatically generated file. DO NOT MODIFY */
package com.cs639.pace123.inpaceimport;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}