package com.cs639.pace123.inpaceimport;

//import com.cs639.pace.inpace.R;
import com.cs639.pace123.inpaceimport.R;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by meghanjordan on 12/11/14.
 */
public class FirstFound extends Activity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.firstfound);


        Button b = (Button) findViewById(R.id.hiButton);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Send email
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                       "mailto", "chandrashekar.yv@gmail.com", null));
                //Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                       // "mailto", "pooja11mahesh@gmail.com", null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "InPace: I am trying to email you through our InPace code!");
                emailIntent.putExtra(Intent.EXTRA_TEXT, "iT Works !! :)");
                startActivity(Intent.createChooser(emailIntent, "Send email..."));
            }
        });

    }
}